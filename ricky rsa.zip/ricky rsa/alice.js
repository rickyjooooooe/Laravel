const crypto = require("crypto");
const fs = require("fs");

const message = "I want some apples";


const privateKey = fs.readFileSync("private.pem", "utf8");

const signer = crypto.createSign("RSA-SHA256");
signer.update(message);
const signature = signer.sign(privateKey, "hex");

console.log("Signature:", signature);
console.log("Message:", message);
