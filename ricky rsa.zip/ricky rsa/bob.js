const crypto = require("crypto");
const fs = require("fs");

const message = "I want some apples";
const signature = "11cf5d3e09079a13e30a3b9fcb119573687ef808278708795fff7ca5ba2d2f3e0871c6d99a9d4b2bc0bc40212af5f9c48e4a778e7f5804744af6bdfe16da1cd9bfc042920cf6487488f34d97245f9df0df4bd5e95774f72bdfdddeb5a794e2ed87400f7c98df8d1cb1849894a8ef717dae86d3884035f733e27dbb3df26daf3d5bcb50581815667cf447d15132b0798d78fe707808576f4479f175c8d0e0ad3120819433fa4831e4015a2ed0e82135bb7b13b40563ff4638a2422c4a78a04fcc652c012a4808990d73a71f5e75ac3e646267974ce841106d7fc1b1cb51fa3a05b42cd4e6338832eef909039843c38f817863c291751bdb745dc866fd06f710db";

const publicKey = fs.readFileSync("public.pem", "utf8");

const verifier = crypto.createVerify("RSA-SHA256");
verifier.update(message);
const isVerified = verifier.verify(publicKey, signature, "hex");

console.log("Signature Verification:", isVerified);
console.log("Message:", message);
