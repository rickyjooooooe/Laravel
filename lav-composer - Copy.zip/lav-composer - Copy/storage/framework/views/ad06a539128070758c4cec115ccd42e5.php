Hello World as Controller

<div>
<h1>Title</h1>
</div>

<?php for($i = 0; $i < 10; $i++): ?>
Number - <?php echo e($i); ?> <br>
<?php endfor; ?>

<h3><?php echo e($name); ?></h3>

Page - <?php echo e($p); ?>

<?php /**PATH D:\xampp8\htdocs\commerce\resources\views/coba.blade.php ENDPATH**/ ?>