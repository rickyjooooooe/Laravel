require("dotenv").config({ path: "./secret.env" });

const http = require("http");
const socketIo = require("socket.io");
const crypto = require("crypto");

const server = http.createServer();
const io = socketIo(server);

const secretKey = process.env.SECRET_KEY;




// Helper function to generate an HMAC hash of the message
function generateHash(data) {
    return crypto.createHmac("sha256", secretKey).update(data).digest("hex");
}

io.on("connection", (socket) => {
    console.log(`Client ${socket.id} connected`);

    socket.on("disconnect", () => {
        console.log(`Client ${socket.id} disconnected`);
    });

    socket.on("message", (data) => {
        const { username, message, hash } = data;

        // Verify the integrity of the message by recalculating the hash
        const recalculatedHash = generateHash(`${username}:${message}`);
        if (recalculatedHash !== hash) {
            console.log(`Message integrity check failed from ${username}. Possible tampering.`);
            socket.emit("error", { error: "Message integrity check failed" });
            return;
        }

        console.log(`Receiving message from ${username}: ${message}`);

        // Broadcast the message to all clients, including the sender
        io.emit("message", { username, message, hash });
    });
});

const port = 3000;
server.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
